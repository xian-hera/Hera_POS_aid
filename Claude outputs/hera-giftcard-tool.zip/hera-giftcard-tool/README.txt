Hera gift card tool / Hera 礼品卡工具
=====================================

用法 / How to use
1. 把整个文件夹复制到电脑上，双击 hera-giftcard-tool.exe。
   Copy this folder to the computer and double-click hera-giftcard-tool.exe.
2. 选 1 生成新一批卡 / 选 2 检查已有的 cards.csv。
   Choose 1 to make a new batch of cards, or 2 to check an existing cards.csv.
3. 输入 GIFT_SECRET（必须和 Render 上的一模一样；输入时屏幕上不会显示任何字符，这是正常的）。
   Enter the GIFT_SECRET (it must be exactly the one on Render; nothing is shown while you type, that is normal).
4. 建议在 "Safety check" 里粘贴一张你已经测试过的卡的 C 码（HGB 开头），用来确认密钥正确。
   At the "Safety check", paste the C code (starts with HGB) of a card you have already tested: it proves the secret is right.
5. 生成的文件在 exe 旁边的 giftcards-output 文件夹里：cards.csv 和 cards.csv.sha256.txt。
   The files appear next to the program in the giftcards-output folder: cards.csv and cards.csv.sha256.txt.

注意 / Notes
- 每份订单只生成一次，并保存好整个文件夹。再运行一次会得到完全不同的码。
  Make ONE batch per print order and keep that folder: a second run gives completely different codes.
- 密钥不会被保存。cards.csv 里有所有兑换码，只发给印刷厂。
  The secret is never saved. cards.csv contains every redeem code: send it only to the print shop.
- Windows 可能提示"Windows 已保护你的电脑"，因为这个程序没有商业数字签名。点"更多信息" -> "仍要运行"。
  Windows may say "Windows protected your PC" because the program has no commercial code-signing certificate. Click "More info" -> "Run anyway".
- 只做生成和检查，不联网，不上传任何东西。
  It only makes and checks files. It does not use the network and uploads nothing.
